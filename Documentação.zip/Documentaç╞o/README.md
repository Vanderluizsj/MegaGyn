# MegaGyn
 
## Aplicação web para cadastro de fichas de treino para alunos da academia

### Versão beta da Api construida e documentada
* Funcionalidades:
   * Criar/editar/pesquisar/deletar de aluno
   * Criar/editar//pesquisar/deletar de treino
   * Criar/editar//pesquisar/deletar de exercicio
* ToDo
   * Front-end ainda não implementado
